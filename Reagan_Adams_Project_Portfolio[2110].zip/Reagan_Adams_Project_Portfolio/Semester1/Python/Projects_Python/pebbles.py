#a program to gather and display game statistics about a local football team
#Date written Sept. 18-19, 2023
#Written by: Noel Hammett

#Print statements to greet the user and gather relevent data
print(f"St.John's Pebbles Football Team")
print(f"Game Statistics Program")
print()
print(f"Please enter the following required values:")
print()
GameDate = input("     Game date (yyyy-mm-dd): ")
Opponent = input("     Opponent: ")
print()
PassAttempts = int(input("     Number of pass attempts:      "))
NumCompletion = int(input("     Number of completions:        "))
TotPassYards = int(input("     Total Passing Yards:          "))
NumTouchDowns = int(input("     Number of touchdowns:         "))
NumInterceptions = int(input("     Number of interceptions:      "))
print()
RushingAttmepts = int(input("     Number of rushing attempts:   "))
TotRushYards = int(input("     Total rushing yards:          "))
NumRushTouchdowns = int(input("     Number of rushing touchdowns: "))

#The game statistics for the quarterback and runningback are displayed below
PassPercent = NumCompletion/PassAttempts
YardsPerPass = TotPassYards/NumCompletion
 
#Special Calculation for the NFL Passer Rating
NFLPasser1 = ((NumCompletion/PassAttempts)-0.3)*5
NFLPasser2 = ((TotPassYards/PassAttempts)-3)*0.25
NFLPasser3 = ((NumTouchDowns/PassAttempts)*20)
NFLPasser4 = (2.375-(NumInterceptions/PassAttempts)*25)
NFLPasserRating = ((NFLPasser1 + NFLPasser2 + NFLPasser3 + NFLPasser4)/6)*100

#calculations for runningback
AverageYardsPerRush = TotRushYards/RushingAttmepts
TouchdownEfficiency = NumRushTouchdowns/RushingAttmepts

#printing out results
print()
print()
print(f"St.John's Pebble Football Team")
print(f"Game Statistics Program")
print()
OpponentDSP = "{:22s}".format(Opponent)
GameDateDSP = "{:10s}".format(GameDate)
print(f"Game Statistics vs {OpponentDSP:<22s}  on  {GameDateDSP:<10s}")
print(f"------------------------------------------------------------")
print(f"Quarterback Statistics: ")
print()
PassPercentDSP = "{:.0%}".format(PassPercent)
print(f"Number of pass attempts:  {PassAttempts:>2d}   Pass Completion %:       {PassPercentDSP:>3s}")
print(f"Number of completions:    {NumCompletion:>2d}")
YardsPerPassDSP = "{:.0f}".format(YardsPerPass)
print(f"Total passing yards:     {TotPassYards:>3d}   Yards per pass:          {YardsPerPassDSP:>3s}")
print(f"Number of touchdowns:      {NumTouchDowns:>1d}")
NFLPasserRatingDSP = "{:.1f}".format(NFLPasserRating)
print(f"Number of interceptions:   {NumInterceptions:>1d}   NFL Passer Rating:     {NFLPasserRatingDSP:>5s}")
print()
print("Rushing Statistics:")
print()
AverageYardsPerRushDSP = "{:.1f}".format(AverageYardsPerRush)
print(f"Number of rushing atts:   {RushingAttmepts:>2d}   Average yards per rush: {AverageYardsPerRushDSP:>4s}")
print(f"Total rushing yards:     {TotRushYards:>3d}")
TouchdownEfficiencyDSP = "{:.1%}".format(TouchdownEfficiency)
print(f"Number of rushing TD's:    {NumRushTouchdowns:>1d}   TD Efficiency:          {TouchdownEfficiencyDSP:>5s}")
print(f"-------------------------------------------------------------")








# Comment like a pro
'''
Age = int(input("Enter a person's age: "))
if Age >= 19:
    print("Allowed to vote")
else:
    print("Too young to vote")
'''

# input user information
PayRate = float(input("Enter the employee pay rate: "))
HoursWorked = int(input("Enter the hours worked: "))

'''
if HoursWorked <= 40:
    GrossPay = HoursWorked * PayRate
else:
    RegPay = PayRate * 40
    OTPay = (HoursWorked - 40) * (PayRate * 1.5)
    GrossPay = RegPay + OTPay

print(GrossPay)
'''
'''
MarStat = input("Enter the marital status (S, M, W, O): ").upper()
if MarStat == "S":
    print("Single")
elif MarStat == "M":
    print("Maried")
elif MarStat == "W":
    print("Widowed")
else: 
    print("Other")
 '''
'''
BalDue = float(input("Enter the balance due: "))
CredLim = float(input("Enter the credit limit: "))

if BalDue <= CredLim:
    Payment = BalDue * .10
else:
    Payment = (BalDue * .10) + (BalDue - CredLim)

    print(Payment)
 '''

NumA = int(input("Enter the first integer: "))
NumB = int(input("Enter the second integer: "))

Sum = NumA + NumB
Diff = NumA - NumB
Prod = NumA * NumB
if NumB != 0:
    Quot = NumA / NumB
else:
    Message = "Division by 0."
NumAEO = NumA % 2
if NumAEO == 0:
    AEO = "Even"
else:
    AEO = "Odd"
NumBEO = NumB % 2
if NumBEO == 0:
    BEO = "Even"
else:
    BEO = "Odd"





if MemType == "S":
    print("Standard")
    MemType = STANDARD_RATE
else: 
    print("Executive")
    MemType = EXECUTIVE_RATE


if WkSiteClean == "Y":
    print("Yes")
    WkSiteClean = WK_SITE_CLEAN_RATE
else:
    print("No")


if VidSurv == "Y":
    print("Yes")
else:
    print("No")

if VidSurv == "Y":
   VidSurv = VID_SURV_RATE
   print(VID_SURV_RATE)
else:
    VidSurv = 0.00
    print(VidSurv)
    

if WkSiteClean == "Y":
    WkSiteClean = WK_SITE_CLEAN_RATE
    print(WK_SITE_CLEAN_RATE)
else:
    WkSiteClean = 0.00
    print(WkSiteClean)











# print(SiteNum, MemName, StAdd, City, Prov, PosCode, CellNum, NumAltMem)
 # used the previous comment to test all varibles thus far.





# Comment like a pro.

InvNo = 1234
InvDate = "23-09-14"
CustName = "Bill Victor"
StAdd = "123 Main St."
City = "St. John's"
Prov = "NL"
Postal = "A18Y8"
PlateNum = "HZF342"
Mileage = 16354

CostLab = 240.00
CostParts = 360.00
Discount = 60.00
HST = 81.00
InvTotal = 621.00 

# Generate the invoice for the customer.
print()
print(f"                       HONEST PETER'S GARAGE")
print(f"                         123 Fixit Street")
print(f"                      St. John's, NL A1A 1A1 ")

print(f"  Invoce#: {InvNo:>4d}                                       Date: {InvDate:<8s}")
print(f"  ------------------------------------------------------------------")
print(f"   Customer: {CustName:<30s}     Plate Number: {PlateNum:<6s}")
print(f"   Address:  {StAdd:<30s}     Mileage:      {Mileage:>6d}")
print(f"             {City:<18s}, {Prov:<2s}  {Postal:<6s}")

print(f"")
CostLabDsp = "${:,.2f}".format(CostLab)
print(f"                                           Cost of Labor:  {CostLabDsp:>9s}") 
CostPartsDsp = "${:,.2f}".format(CostParts)
print(f"                                           Cost of Parts:  {CostPartsDsp:>9s}")
DiscountDsp ="${:,.2f}".format(Discount) 
print(f"                                          Total Discount:  {DiscountDsp:>9s}")
HSTDsp = "${:,.2f}".format(HST)
print(f"                                                     HST:  {HSTDsp:>9s}")
print(f"                                                             -------")
InvTotalDsp = "${:,.2f}".format(InvTotal)
print(f"                                           Invoice Total:  {InvTotalDsp:>9s}")
print(f"  ------------------------------------------------------------------")
print(f"      Honest Peter's - There to meet the needs of our customers!!")
print(f"  ------------------------------------------------------------------")
print()
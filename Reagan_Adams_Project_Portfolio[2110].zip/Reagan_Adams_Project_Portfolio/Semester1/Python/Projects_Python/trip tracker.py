# Program to generate and calculate claim amounts for employees from buisness trips.
# Date written : Sept 11, 2023 - End Date
# Author: Reagan Adams 

# Define program constants
PER_DIEM_RATE = 56.00
ROOM_RENTAL_RATE = 125.00
PER_KILO_RATE = 0.24

# User inputs
SalesName = input("Enter the sales person name: ")
Location = input("Enter the location of the trip: ")
NumDays = input("Enter the number of days: ")
NumDays = int(NumDays)
NumKilos = input("Enter the number of kilometers: ")
NumKilos = float(NumKilos)

# Required program calculations
PerDiemAmt = NumDays * PER_DIEM_RATE
NumNights = NumDays - 1   # Subtract 1 from the total days to give the total nights.
LodgingAmt = NumNights * ROOM_RENTAL_RATE
MilAmt = NumKilos * PER_KILO_RATE
TotalClaim = PerDiemAmt + LodgingAmt + MilAmt

# User display of results
print("Sales person name: ", SalesName)
print("Trip location: ", Location)
print("Number of days: ", NumDays)
print("Total Kilometers travelled: ", NumKilos)
print("Per diem amount: ", PerDiemAmt)
print("Lodging amount: ", LodgingAmt)
print("Mileage amount: ", MilAmt)
print("Total claim amount: ", TotalClaim)

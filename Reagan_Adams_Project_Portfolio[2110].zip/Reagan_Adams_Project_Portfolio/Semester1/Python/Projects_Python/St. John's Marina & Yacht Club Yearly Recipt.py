
# Program to calculate and generate members recipt of their yearly expenses.
# Date written Oct. 1 -Oct. 6, 2023.
# Author: Reagan Adams, QAP 2.

# User Inputs

SiteNum = int((input("Enter site number (1 - 100): ")))
MemName = input("Enter the member name: ")
StAdd = input("Enter the street address: ")
City = input("Enter the city: ")
Prov = input("Enter the provience: ")
PosCode = input("Enter the postal code: ")
HomePhNum = input("Enter the home phone number (H): ")
CellPhNum = input("Enter the cell phone number (C): ")
MemType = input("Enter the membership type (S for standard, E for executive): ").upper()
NumAltMem = int(input("Enter the number of alternate members (Family and friends who will be allowed access to grounds):  "))
WkSiteClean = input("Enter choice for weekly site cleaning (Y for yes, N for No): ").upper()
VidSurv = input("Enter choice for video surveillance (Y for yes, N for No): ").upper()


# Define program constants
EVEN_RATE = 80.00
ODD_RATE = 120.00
ALT_MEM_RATE = 5
WK_SITE_CLEAN_RATE = 50.00
VID_SURV_RATE = 35.00
HST_RATE = .15
STANDARD_RATE = 75.00
EXECUTIVE_RATE = 150.00
PROCESSING_FEE_RATE = 59.99
CANCEL_FEE_RATE = 0.60

# Calculation for cost of alternate members
AltMemCost = float(NumAltMem * ALT_MEM_RATE) 

# if statments for input statments that have a choice of answer
if MemType == "S":
    MemType = "Standard"
elif MemType == "E":
    MemType = "Executive"
else:
    print("Please enter S or E.")

SiteNumAEO = SiteNum % 2
if SiteNumAEO == 0:
    SiteCost = EVEN_RATE     
else:
    SiteCost = ODD_RATE

 # Calculation for site charges   
SiteCharge = float(SiteCost + AltMemCost)

 # if statement for amount of alternate members   
if NumAltMem > 0:
    NumAltMem * ALT_MEM_RATE
else:
    NumAltMem == NumAltMem
    
# calcuation for extra charge cost
ExCharge = float(WK_SITE_CLEAN_RATE + VID_SURV_RATE)

# if statements for what to do if member syays yes or no to cleaning and video surviellance
if WkSiteClean == "Y":
    WkSiteClean = "YES"
else:
    WkSiteClean = "NO"

if VidSurv == "Y":
    VidSurv = "YES"
else:
    VidSurv ="NO"

if WkSiteClean == "Y":
    ExCharge += WK_SITE_CLEAN_RATE
else:
    ExCharge != WK_SITE_CLEAN_RATE

if VidSurv == "Y":
    ExCharge += VID_SURV_RATE
else:
    ExCharge != VID_SURV_RATE

# calculations for subtotal, salestax and total monthly charge
SubTotal = float(SiteCharge + ExCharge)
SalesTax = float(SubTotal * HST_RATE)
TotMonthCharge = float(SubTotal + SalesTax)

# if statements for rates of the two memberships
if MemType == "S":
    MonthDue = STANDARD_RATE
else:
    MonthDue = EXECUTIVE_RATE

# calculations for total monthly fee, total yearly fee, monthly payment and cancellation fee
TotalMonthFee = float(TotMonthCharge + MonthDue)
TotYearFee = float(TotalMonthFee * 12)
TotMonthPay = float((TotYearFee + PROCESSING_FEE_RATE)) / 12
CancelFee = float(TotYearFee * CANCEL_FEE_RATE)

# output results
print()
print(f"    St. John's Marina & Yacht Club ")
print(f"          Yearly Member Receipt")
print("---------------------------------------")
print()
print(f"Client Name and Address: ")
print()
MemNameDsp = "{:46s}".format(MemName)
StAddDsp = "{:15s}".format(StAdd)
CityDsp = "{:2s}".format(City)
PosCodeDsp = "{:6s}".format(PosCode)
print(f"{MemNameDsp:<46s}") 
print(f"{StAddDsp:<15s}          , {CityDsp:>2s}    {PosCodeDsp:>6s}")
print()
print(f"Phone: {HomePhNum:<10s} (H)")
print(f"       {CellPhNum:<10s} (C)")
print()
print(f"Site #: {SiteNum:<3d}   Member type:     {MemType:<9s}") 
print()
print(f"Alternate members:                   {NumAltMem:>2d}")
print(f"Weekly site cleaning:               {WkSiteClean:>3s}")
print(f"Video Surveillance:                 {VidSurv:3s}")
print()
SiteChargeDsp = "${:,.2f}".format(SiteCharge)
ExChargeDsp = "${:.2f}".format(ExCharge)
print(f"Site charges:                 {SiteChargeDsp:>9s}")
print(f"Extra charges:                  {ExChargeDsp:>7s}")
print(f"                               --------")
SubTotalDsp = "${:,.2f}".format(SubTotal)
SalesTaxDsp = "${:.2f}".format(SalesTax)
print(f"Subtotal:                     {SubTotalDsp:>9s}")
print(f"Sales tax (HST):                {SalesTaxDsp:>7s}")
print(f"                               --------")
TotMonthChargeDsp = "${:,.2f}".format(TotMonthCharge)
MonthDueDsp = "${:.2f}".format(MonthDue)
print(f"Total monthly charges:        {TotMonthChargeDsp:>9s}")
print(f"Monthly dues:                   {MonthDueDsp:>7s} ")
print(f"                               --------")
TotalMonthFeeDsp = "${:,.2f}".format(TotalMonthFee)
TotYearFeeDsp = "${:.2f}".format(TotYearFee)
print(f"Total monthly fees:           {TotalMonthFeeDsp:>9s}")
print(f"Total yearly fees:           {TotYearFeeDsp:>10s}")
print()
TotMonthPayDsp = "${:,.2f}".format(TotMonthPay)
print(f"Monthly payment:              {TotMonthPayDsp:>9s}")
print(f"---------------------------------------")
print(f"Issued: 2023-09-07")
print(f"HST Reg No: 549-33-5849-4720-9885")
print()
CancelFeeDsp = "${:,.2f}".format(CancelFee)
print(f"Cancellation fee:             {CancelFeeDsp:>9s} ")

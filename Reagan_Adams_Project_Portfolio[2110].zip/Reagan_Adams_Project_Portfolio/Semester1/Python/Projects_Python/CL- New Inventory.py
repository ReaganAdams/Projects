

ItemName = input("Enter the inventory item name: ")
ItemCost = input("Enter the item cost:  $")
ItemCost = float(ItemCost)
NumInStock = input("Enter the number of items in stock: ")
NumInStock = int(NumInStock)

RetailPrice = ItemCost  + (ItemCost * .75)
TotalInvCost = ItemCost * NumInStock
TotalInvRet = RetailPrice * NumInStock
GrossMargin = TotalInvRet - TotalInvCost
Off10 = RetailPrice - (RetailPrice * .10)
Off25 = RetailPrice - (RetailPrice * .25)
Off33 = RetailPrice - (RetailPrice * .33)
Off50 = RetailPrice - (RetailPrice * .50)

print("Iteam name: ", ItemName)
print("Retail price", RetailPrice )
print("Gross maargin", GrossMargin)
print("Off 50 of sales price: ", Off50)
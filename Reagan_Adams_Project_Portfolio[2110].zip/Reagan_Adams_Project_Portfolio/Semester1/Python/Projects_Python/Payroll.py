# Comment like a pro

# Define program constants.
PAY_RATE = 17.00
SALES_COMM_RATE = .06
ASS_COMM_RATE = .45
IT_RATE = .17
CPP_RATE = .0495
EI_RATE = .016
UNION_DUES = 12.00
MED_BEN_RATE = .05

# Gather user inputs.
EmpName = "John Smith"  # input("Enter the employee name: ")
HoursWorked = 40  # int(input("Enter the number of hours worked (20 - 60)"))
TotalSales = 4000.00  # float(input("Enter the total sales  (1000.00 - 7000.00) $"))
ItemsAss = 30.00  # int(input("Enter the total number of items assembled"))

# print(EmpName, HoursWorked, TotalSales, ItemsAss) # used to check all work done thus far

# Calculate required data.
RegPay = HoursWorked * PAY_RATE
SalesComm = TotalSales * SALES_COMM_RATE
AssComm = ItemsAss + ASS_COMM_RATE
TotalComm = SalesComm * AssComm
GrossPay = RegPay + SalesComm + AssComm


IncomeTax = GrossPay * IT_RATE
CPP = GrossPay * CPP_RATE
EI = GrossPay * EI_RATE
MedBen = GrossPay * MED_BEN_RATE
TotalDed = IncomeTax + CPP + EI + MedBen + UNION_DUES

NetPay = GrossPay - TotalDed

# Generate program output.

print()
print(f"   ABC CONPANY")
print(f"   Employee Weekly Payroll Summary")
print()
print(f"   Employee name:  {EmpName:<20s}")
print()
PayRateDsp = "${:,.2f}".format(PAY_RATE)
print(f"   Hours worked: {HoursWorked:>2d}     Pay Rate: {PayRateDsp:>6s} ")
print()
SalesCommRateDsp = "{:.0%}".format(SALES_COMM_RATE)
AssCommRateDsp = "{:.2f}".format(ASS_COMM_RATE)
print(f"   Commission rates:    On sales:    {SalesCommRateDsp:>3s}    On assemblies: {AssCommRateDsp:>4s}")
print()
RegPayDsp = "${:,.2f}".format(GrossPay)
print(f"        Regular pay:                        {RegPayDsp:>9s}")
print()
SalesCommDsp = "${:,.2f}".format(SalesComm)
AssCommDsp = "${:,.2f}".format(AssComm)
print(f"           Sales Commission:     {SalesCommDsp:>9s}")
print(f"           Assembly Commission:  {AssCommDsp:>9s}")
print(f"                                   -------    --------")

